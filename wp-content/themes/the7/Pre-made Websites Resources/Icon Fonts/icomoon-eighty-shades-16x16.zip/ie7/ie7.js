/* To avoid CSS expressions while still supporting IE 7 and IE 6, use this script */
/* The script tag referencing this file must be placed before the ending body tag. */

/* Use conditional comments in order to target IE 7 and older:
	<!--[if lt IE 8]><!-->
	<script src="ie7/ie7.js"></script>
	<!--<![endif]-->
*/

(function() {
	function addIcon(el, entity) {
		var html = el.innerHTML;
		el.innerHTML = '<span style="font-family: \'icomoon-eighty-shades-16x16\'">' + entity + '</span>' + html;
	}
	var icons = {
		'icon-store': '&#xe900;',
		'icon-out': '&#xe901;',
		'icon-in': '&#xe902;',
		'icon-in-alt': '&#xe903;',
		'icon-home': '&#xe904;',
		'icon-lightbulb': '&#xe905;',
		'icon-anchor': '&#xe906;',
		'icon-feather': '&#xe907;',
		'icon-expand': '&#xe908;',
		'icon-maximize': '&#xe909;',
		'icon-search': '&#xe90a;',
		'icon-zoomin': '&#xe90b;',
		'icon-zoomout': '&#xe90c;',
		'icon-add': '&#xe90d;',
		'icon-subtract': '&#xe90e;',
		'icon-exclamation': '&#xe90f;',
		'icon-question': '&#xe910;',
		'icon-close': '&#xe911;',
		'icon-cmd': '&#xe912;',
		'icon-forbid': '&#xe913;',
		'icon-book': '&#xe914;',
		'icon-spinner': '&#xe915;',
		'icon-play': '&#xe916;',
		'icon-stop': '&#xe917;',
		'icon-pause': '&#xe918;',
		'icon-forward': '&#xe919;',
		'icon-rewind': '&#xe91a;',
		'icon-sound': '&#xe91b;',
		'icon-sound-alt': '&#xe91c;',
		'icon-soundoff': '&#xe91d;',
		'icon-task': '&#xe91e;',
		'icon-inbox': '&#xe91f;',
		'icon-inbox-alt': '&#xe920;',
		'icon-envelope': '&#xe921;',
		'icon-compose': '&#xe922;',
		'icon-newspaper': '&#xe923;',
		'icon-newspaper-alt': '&#xe924;',
		'icon-clipboard': '&#xe925;',
		'icon-calendar': '&#xe926;',
		'icon-hyperlink': '&#xe927;',
		'icon-trash': '&#xe928;',
		'icon-trash-alt': '&#xe929;',
		'icon-grid': '&#xe92a;',
		'icon-grid-alt': '&#xe92b;',
		'icon-menu': '&#xe92c;',
		'icon-list': '&#xe92d;',
		'icon-gallery': '&#xe92e;',
		'icon-calculator': '&#xe92f;',
		'icon-windows': '&#xe930;',
		'icon-browser': '&#xe931;',
		'icon-alarm': '&#xe932;',
		'icon-clock': '&#xe933;',
		'icon-attachment': '&#xe934;',
		'icon-settings': '&#xe935;',
		'icon-portfolio': '&#xe936;',
		'icon-user': '&#xe937;',
		'icon-users': '&#xe938;',
		'icon-heart': '&#xe939;',
		'icon-chat': '&#xe93a;',
		'icon-comments': '&#xe93b;',
		'icon-screen': '&#xe93c;',
		'icon-iphone': '&#xe93d;',
		'icon-ipad': '&#xe93e;',
		'icon-forkandspoon': '&#xe93f;',
		'icon-forkandknife': '&#xe940;',
		'icon-instagram': '&#xe941;',
		'icon-facebook': '&#xe942;',
		'icon-delicious': '&#xe943;',
		'icon-googleplus': '&#xe944;',
		'icon-dribbble': '&#xe945;',
		'icon-pin': '&#xe946;',
		'icon-pin-alt': '&#xe947;',
		'icon-camera': '&#xe948;',
		'icon-brightness': '&#xe949;',
		'icon-brightness-half': '&#xe94a;',
		'icon-moon': '&#xe94b;',
		'icon-cloud': '&#xe94c;',
		'icon-circle-full': '&#xe94d;',
		'icon-circle-half': '&#xe94e;',
		'icon-globe': '&#xe94f;',
		'0': 0
		},
		els = document.getElementsByTagName('*'),
		i, c, el;
	for (i = 0; ; i += 1) {
		el = els[i];
		if(!el) {
			break;
		}
		c = el.className;
		c = c.match(/icon-[^\s'"]+/);
		if (c && icons[c[0]]) {
			addIcon(el, icons[c[0]]);
		}
	}
}());
